package com.cg.bloggerszone.dao;


import java.sql.SQLException;
import java.util.List;

import com.cg.bloggerszone.dto.Blog;


public interface IBlogDao {
	
	public Blog saveBlog(Blog blog) throws SQLException;
	
	public List<Blog> findByTitle(String title);

	public List<Blog> findByBloggerName(String name);

}
