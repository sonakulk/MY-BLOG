package com.cg.bloggerszone.dao;

import java.sql.SQLException;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.Query;
import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.dto.Blogger;
import com.cg.bloggerszone.exceptions.BlogException;
import com.cg.bloggerszone.util.ConnectionDBUtil;
import com.cg.bloggerszone.util.Queries;

public class BlogDaoImpl implements IBlogDao{
	EntityManager em;
	public BlogDaoImpl() {}
	/** 
	 * This method is used to save the blog added by the blogger. 
	 * @throws SQLException 
	 * */
	public Blog saveBlog(Blog blog)  {	
		try {
			em=ConnectionDBUtil.getConnection();
			Blogger blogger=em.find(Blogger.class, blog.getBlogger().getId());
			Blog blogg=em.find(Blog.class, blog.getTitle());
			if(blogg!=null)
				throw new BlogException("title already exist");
			if(blogger==null) 
			{
				em.persist(blog);			
			}else {
				blog.setBlogger(blogger);
				em.merge(blog);	
			}	                                                                                           
			em.getTransaction().commit();
			return blog;
		}
		finally{
			if(em!=null)
				em.close();
		}
	}
	/** 
	 * This method is used to search the blogger . 
	 * @param title this parameter is used to find the blogs by given title
	 * */
	public List<Blog> findByTitle(String title) {
		try {
			em=ConnectionDBUtil.getConnection();
			Query query =em.createQuery(Queries.searchByTitle);
			query.setParameter("title",title+"%");
			List<Blog> bloglist= query.getResultList();	
			em.getTransaction().commit();
			return bloglist;	}	
		finally 
		{
			if(em!=null)
				em.close();
		}
	}	
	/** 
	 * This method is used to search the blogger . 
	 * @param name this parameter is used to find the blogs by given bloggername.
	 * */
	public List<Blog> findByBloggerName(String name) 
	{	
		try {
			em=ConnectionDBUtil.getConnection();
			Query query =em.createQuery(Queries.searchByBloggerName);
			query.setParameter(1, name+"%");
			List<Blog> bloglist=query.getResultList();
			em.getTransaction().commit();
			return bloglist;
		}
		finally 
		{
			if(em!=null)
				em.close();
		}
	}
}





