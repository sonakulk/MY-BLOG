package com.cg.bloggerszone.util;

public interface Queries {

	public static String  searchByTitle="FROM Blog b WHERE b.title Like :title";
	public static String  searchByBloggerName="SELECT b from Blog b ,IN (b.blogger) br WHERE br.name LIKE ?";
	
}
