package com.cg.bloggerszone.service;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bloggerszone.dao.BlogDaoImpl;
import com.cg.bloggerszone.dao.IBlogDao;
import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.exceptions.BlogException;
import com.cg.bloggerszone.util.ConnectionDBUtil;

public class BlogServiceImpl implements IBlogService {

	IBlogDao dao;
	Blog blog;
	public BlogServiceImpl() {	
		dao=new BlogDaoImpl();
	}
	/** 
	 * This method is used to save the blog added by the blogger. 
	 * @throws SQLException 
	 * */
	public Blog addBlog(Blog blog) throws SQLException  {

		return dao.saveBlog(blog);
	}
	/** 
	 * This method is used to search the blogger . 
	 * @param title this parameter is used to find the blogs by given title
	 * */
	public List<Blog> searchByTitle(String title) {	
		List<Blog> bloglist=dao.findByTitle(title);
		if(bloglist.isEmpty()) 
			throw new BlogException("Blogs with this title not found");
		return dao.findByTitle(title);
	}
	/** 
	 * This method is used to search the blogger . 
	 * @param name this parameter is used to find the blogs by given bloggername.
	 * */
	public List<Blog> searchByBloggerName(String name) {
		List<Blog> bloglist=dao.findByBloggerName(name);
		if(bloglist.isEmpty()) 
			throw new BlogException("Blogs of this blogger not found");
		return dao.findByBloggerName(name);
	}

}
