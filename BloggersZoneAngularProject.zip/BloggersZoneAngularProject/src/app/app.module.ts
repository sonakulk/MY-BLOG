﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import  { HttpClientModule }  from '@angular/common/http'; 
//import {FormsModule} from '@angular/Forms';
import {NgxPaginationModule} from 'ngx-pagination';
import {AddBlog} from './app.addblogcomponent';
import {AddBlogByExistingBlogger} from './app.addbyexistingbloggercomponent';
import {SearchBlog} from './app.searchblogcomponent';
import {SearchBlogByBlogger} from './app.searchbybloggercomponent';
 import { ReactiveFormsModule,Validators ,FormBuilder} from '@angular/forms';
import {Routes,RouterModule} from '@angular/router';




const route:Routes=[
    {path:'add',component:AddBlog},
    {path:'addexist',component:AddBlogByExistingBlogger},
    {path:'searchbytitle',component:SearchBlog},
     {path:'searchbyblogger',component:SearchBlogByBlogger}

  

];
@NgModule({
    imports: [
        BrowserModule,HttpClientModule,RouterModule.forRoot(route),ReactiveFormsModule,NgxPaginationModule
        
    ],
    declarations: [
        AppComponent,AddBlog,AddBlogByExistingBlogger,SearchBlog,SearchBlogByBlogger
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }