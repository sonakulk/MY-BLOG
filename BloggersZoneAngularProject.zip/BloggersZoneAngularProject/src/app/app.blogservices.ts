import { Injectable } from '@angular/core';
import { HttpClient ,HttpParams} from '@angular/common/http';
import { Blog } from './app.blog';
import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';




@Injectable({
providedIn:'root'    
})
export class BlogService{

constructor(private http:HttpClient){}

addBlog(blog:any){
  
            let input=new FormData();
            input.append("title",blog.title);
              input.append("type",blog.type);
            input.append("content",blog.content);
            input.append("blogger.id",blog.id);
            input.append("blogger.name",blog.name);
             input.append("blogger.email",blog.email);
              input.append("blogger.mobileNumber",blog.mobileNumber);

// return this.http.post("http://localhost:9098/bloggerszone/addblog",input).pipe(
//         retry(1),
//         catchError(this.handleError)
//       );
return this.http.post("http://localhost:9098/bloggerszone/addblog",input).pipe(
        retry(1),
        catchError(this.handleError)
      );;
      

}


addExistBlog(blog:any){
            let input=new FormData();
            input.append("title",blog.title);
            input.append("type",blog.type);
            input.append("content",blog.content);
            input.append("blogger.id",blog.id);          

return this.http.post("http://localhost:9098/bloggerszone//addbyexistblogger",input).pipe(
        retry(1),
        catchError(this.handleError)
      );;

}


searchByTitle(title:string)
{

 let httpParams = new HttpParams().set("title",title);
 return this.http.get("http://localhost:9098/bloggerszone/searchbytitle",{params:httpParams}).pipe(
        retry(1),
        catchError(this.handleError)
      );

 
 
}
searchByBloggerName(name:string)
{

 let httpParams = new HttpParams().set("name",name);
 return this.http.get("http://localhost:9098/bloggerszone/searchbybloggername",{params:httpParams}).pipe(
        retry(1),
        catchError(this.handleError)
      );

}



handleError(error) {
   let errorMessage = '';
   if (error.error instanceof ErrorEvent) {
     // client-side error
     errorMessage = `Error: ${error.error}`;
   } else {
     // server-side error
     errorMessage = `\nMessage: ${error.error}`;
   }
   window.alert(errorMessage);
   return throwError(errorMessage);
 }

}
