import{Component} from '@angular/core';
import { OnInit } from '@angular/core';
import { BlogService } from './app.blogservices';
import { Blog } from './app.blog';
import { FormGroup, FormControl,FormBuilder,Validators } from '@angular/forms';


@Component({
    selector:'addexist-blog',
    templateUrl:'app.addbyexistingblogger.html'
})
export class AddBlogByExistingBlogger {

   blogs:Blog[];  
   model:any ={};
  msg:string="Blog added successfully..";
    addBlogExistForm =this.fb.group({
     title: ['',Validators.required],
   type: ['',Validators.required],
   content:['',Validators.required],
     id: ['',Validators.required],
    
    
  });
  
    


constructor(private blogservice:  BlogService,private fb: FormBuilder){
   // console.log("prod constructor");
}




addBlogg()
{
     this.model.title=this.addBlogExistForm.value.title;
     this.model.type=this.addBlogExistForm.value.type;
        this.model.content=this.addBlogExistForm.value.content;
           this.model.id=this.addBlogExistForm.value.id;
  
    console.log(this.model);  
    this.blogservice.addExistBlog(this.model).subscribe((data:any)=>console.log(data));
   
     alert("data added");

}
// addBlogg()
// {
    
//     //this.proservice.addAllPro(this.model).subscribe(data=>console.log(data));
//     console.log(this.model);  
//     this.blogservice.addExistBlog(this.model).subscribe((data:any)=>console.log(data));
     

// }


}