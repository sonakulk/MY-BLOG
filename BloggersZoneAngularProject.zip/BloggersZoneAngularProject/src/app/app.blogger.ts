export class Blogger{

    id:number;
    name:string;
    email:string;
    mobileNumber:number;

}