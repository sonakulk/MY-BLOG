import{Component} from '@angular/core';
import { OnInit } from '@angular/core';
import { BlogService } from './app.blogservices';
import { Blog } from './app.blog';
import { FormGroup, FormControl ,Validators,FormBuilder} from '@angular/forms';


@Component({
    selector:'search-blog',
    templateUrl:'app.searchblog.html'
})
export class SearchBlog {
title:string;
   blogs:Blog[];  
   error:string='';

   searchBlogForm = this.fb.group({
    title: [''],
   
    
  });
  
constructor(private blogservice:  BlogService,private fb: FormBuilder){
   // console.log("prod constructor");
}

searchByTitle(){
 //  this.model.title=this.addBlogForm.value.title;
      this.blogservice.searchByTitle(this.searchBlogForm.value.title).subscribe((data:any)=>this.blogs=data,error => {
        this.error = error;
      });

}
}