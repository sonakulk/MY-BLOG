package com.cg.bloggerszone.util;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Component;

import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.dto.Blogger;
//@Component
public class DBUtil {
	
	 static Timestamp timestamp = new Timestamp(System.currentTimeMillis());
	 static Blogger blogger = null;
	static StringBuffer sb;
	public  static List<Blog> blogs= new ArrayList<Blog>();

	
}
