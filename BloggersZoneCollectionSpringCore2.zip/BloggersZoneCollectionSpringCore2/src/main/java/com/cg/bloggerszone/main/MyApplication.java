package com.cg.bloggerszone.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.bloggerszone.config.JavaConfig;
import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.dto.Blogger;
import com.cg.bloggerszone.exceptions.BlogException;
import com.cg.bloggerszone.service.BlogServiceImpl;
import com.cg.bloggerszone.service.IBlogService;
import com.cg.bloggerszone.util.DBUtil;
/** 
 * @Last Modified on 15-05-2019
 * This is the MyApplication class contains the main method which contains all the functionalities in the project. 
 * @author Sonal Kulkarni. 
 * 
 */

@Component
public class MyApplication {
	@Autowired
	IBlogService blogService;
	static IBlogService service;
	@PostConstruct
	public void init()
	{
		service=this.blogService;
	}
	/** 
	 * This is the main method which makes use of all the functionalities in the project. 
	 * @param args Unused. 
	 * @return Nothing. 
	 */

	public static void main(String args[]) throws IOException {
		ApplicationContext app = new AnnotationConfigApplicationContext(JavaConfig.class);
		Blog blog=null;
		Blogger blogger=null ;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		Scanner scr = new Scanner(System.in);
		StringBuilder content = null;
		int ch;
		do {
			print();
			System.out.println("Enter your choice");
			ch=scr.nextInt();

			StringBuilder bcontent;
			switch(ch) {
			case 1:
				/*
				 * @Last Modified on 15-05-2019
				 * The Following case is adding blog and blogger into collection 
				 * @return Blog
				 */
				System.out.println("Enter Blogger Id");
				int id= scr.nextInt();
				System.out.println("Enter Blogger Name");
				String name= br.readLine();
				System.out.println("Enter Email ");
				String email=br.readLine();
				System.out.println("Mobile Number");
				BigInteger mobileNumber=scr.nextBigInteger();
				System.out.println("Enter Blog Title");
				String title= br.readLine();
				System.out.println("Enter Blog Type");
				String type= br.readLine();
				System.out.println("Enter Blog Content");
				content= new StringBuilder(" ");
				String write;
				while (!((write =
						scr.next()).endsWith(".")))
				{
					content.append(write);
					content.append(" ");
				}
				blogger = (Blogger) app.getBean("blogger");
				blogger.setId(id);
				blogger.setName(name);
				blogger.setEmail(email);
				blogger.setMobileNumber(mobileNumber);						
				blog = (Blog) app.getBean("blog");
				blog.setTitle(title);
				blog.setType(type);
				blog.setTime(new Timestamp(System.currentTimeMillis()));
				blog.setContent(content);
				blog.setBlogger(blogger);				
				if(blogger.getId()==id) {
					blogger.setId(id);
					blog.setBlogger(blogger);
					service.addBlog(blog);}
				else {service.addBlog(blog);}
				break;
			case 2:
				/*
				 * @Last Modified on 15-05-2019
				 * The Following case is for finding blog from collection by given blogger name
				 * @param title This contains the title of the blog to be searched 
				 * @return list of Blogs
				 */
				System.out.println("Enter The Blog Title");
				String blogtitle=scr.next();
				try {
					List<Blog> blogs=service.searchByTitle(blogtitle);
					for(Blog b: blogs) {
						System.out.println("**********************************");
						System.out.println("Title:"+b.getTitle());	
						System.out.println("Blog Type:"+b.getType());	
						System.out.println("\n"+b.getContent());	
						System.out.println("Time:"+b.getTime());	
						System.out.println("Blog By:"+b.getBlogger().getName());
						System.out.println("Blogger Id:"+b.getBlogger().getId());
					}
				}catch(BlogException e) {
					System.out.println(e.getMessage());
				}

				break;		
			case 3:
				/*
				 * @Last Modified on 15-05-2019
				 * The Following case is for finding blog from collection by given blogger name
				 * @param blogger name This  contains the bloggername of the blog to be searched 
				 * @return list of Blogs
				 */
				System.out.println("Enter The Blogger Name");
				String bloggername=br.readLine();
				try {

					List<Blog> blogSearch=service.searchByBloggerName(bloggername);	
					for(Blog bl: blogSearch) {
						System.out.println("**********************************");
						System.out.println("Title:"+bl.getTitle());	
						System.out.println("Blog Type:"+bl.getType());	
						System.out.println("\n"+bl.getContent());	
						System.out.println("Time:"+bl.getTime());	
						System.out.println("Blog By:"+bl.getBlogger().getName());
						System.out.println("Blogger Id:"+bl.getBlogger().getId());
						System.out.println("**********************************");}
				}
				catch(BlogException e) {
					System.out.println(e.getMessage());

				}
				break;	
			case 4:
				/*
				 * @Last Modified on 15-05-2019
				 * The Following case is adding blog with existing blogger into collection 
				 * @return Blog
				 */
				System.out.println("Enter Blogger Id");
				int bid= scr.nextInt();
				System.out.println("Enter Blog Title");
				String btitle= br.readLine();
				System.out.println("Enter Blog Type");
				String btype= br.readLine();
				System.out.println("Enter Blog Content");
				bcontent= new StringBuilder(" ");
				String bwrite;
				while (!((bwrite =
						scr.next()).endsWith(".")))
				{
					bcontent.append(bwrite);
					bcontent.append(" ");
				}

				blog = (Blog) app.getBean("blog");
				blog.setTitle(btitle);
				blog.setType(btype);
				blog.setTime(new Timestamp(System.currentTimeMillis()));
				blog.setContent(bcontent);
				blogger = (Blogger) app.getBean("blogger");
				blogger.setId(bid);
				blogger.setName(blogger.getName());
				blog.setBlogger(blogger);
				service.addBlog(blog);
				break;
			case 5:	
				/*
				 * @Last Modified on 15-05-2019
				 * The Following case is for exit
				 * @return Blog
				 */
				System.out.println("Exit");
				System.exit(0);

				break;
			default:
				System.out.println("Invalid Choice");break;
			}
		}while(ch<5);
	}
	public static void print() {
		System.out.println("********************************************");
		System.out.println("1.Add Blog");
		System.out.println("2.Search Blog by Title");
		System.out.println("3.Search Blog by Blogger Name");
		System.out.println("4.Add Blog By Existing Blogger");
		System.out.println("5.Exit");

		System.out.println("********************************************");
	}
}
