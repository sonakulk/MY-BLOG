package com.cg.bloggerszone.service;

import java.util.List;

import com.cg.bloggerszone.dto.Blog;

public interface IBlogService {

	public Blog addBlog(Blog blog);

	public List<Blog> searchByTitle(String title);

	public List<Blog> searchByBloggerName(String name);	
	
	public Blog searchById(int id);
}
