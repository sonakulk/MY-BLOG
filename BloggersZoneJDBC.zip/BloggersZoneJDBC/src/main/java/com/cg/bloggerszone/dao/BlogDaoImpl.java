package com.cg.bloggerszone.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.dto.Blogger;
import com.cg.bloggerszone.exceptions.BlogException;
import com.cg.bloggerszone.util.ConnectionDBUtil;


public class BlogDaoImpl implements IBlogDao{

	ResultSet rs;
	public BlogDaoImpl() {}
	/** 
	 * This method is used to save the blog added by the blogger. 
	 * @throws SQLException 
	 * */
	public Blog saveBlog(Blog blog)  {
		Connection con = ConnectionDBUtil.getConnection();
		PreparedStatement pstmt=null;
		PreparedStatement pstone=null;
		PreparedStatement psttwo=null;
		PreparedStatement ps=null;
		String queryone="insert into blogger(id,name,email,mobileNumber) values (?,?,?,?)";
		String blogger_exist = "select id from blogger where id = ?";
		String query="insert into blog (title,content,type,time,id)VALUES(?,?,?,?,?)";
		try {
			psttwo = con.prepareStatement(blogger_exist);
			psttwo.setInt(1, blog.getBlogger().getId());
			ResultSet result =psttwo.executeQuery();
			
			if (result.next()) {			
				ps= con.prepareStatement(query);
				ps.setString(1, blog.getTitle());
				ps.setString(2, blog.getContent().toString());
				ps.setString(3, blog.getType());
				ps.setString(4,blog.getTime().toString());				
				ps.setInt(5, blog.getBlogger().getId());
				ps.executeUpdate();	
				ps.close();
			} 

			else {
				pstone = con.prepareStatement(queryone);		
				pstone.setInt(1, blog.getBlogger().getId());
				pstone.setString(2, blog.getBlogger().getName());
				pstone.setString(3, blog.getBlogger().getEmail());
				pstone.setString(4, blog.getBlogger().getMobileNumber().toString());

				pstone.executeUpdate();
				pstone.close();		

				pstmt = con.prepareStatement(query);
				pstmt.setString(1, blog.getTitle());
				pstmt.setString(2, blog.getContent().toString());
				pstmt.setString(3, blog.getType());
				pstmt.setString(4,blog.getTime().toString());				
				pstmt.setInt(5, blog.getBlogger().getId());

				pstmt.executeUpdate();
				pstmt.close();
					
			}
		}
		catch (SQLException e) {
			throw new BlogException("Error while insering record");
		}
		finally {
			try {						
				psttwo.close();	

			} catch (SQLException e) {			
				throw new BlogException("CONNECTION NOT CLOSED");
			}
		}
		return null;
	}	

	/** 
	 * This method is used to search the blogger . 
	 * @param title this parameter is used to find the blogs by given title
	 * */

	public List<Blog> findByTitle(String title) {
		Connection con=ConnectionDBUtil.getConnection();
		PreparedStatement pst=null;
		List<Blog> bloglist = new ArrayList<Blog>();
		String query1="select b.title, b.content, b.type, b.time, br.id, br.name from blog b INNER JOIN  blogger br  on b.Id=br.Id WHERE b.title LIKE ? ";
		try {
			pst=con.prepareStatement(query1);
			pst.setString(1,title+"%");
			rs=pst.executeQuery();
			while(rs.next())
			{				
				Blog blog= new Blog();
				Blogger bloggerone= new Blogger();
				blog.setTitle(rs.getString(1));
				blog.setContent(new StringBuffer(rs.getString(2)));
				blog.setType(rs.getString(3));
				blog.setTime(rs.getTimestamp(4));
				bloggerone.setId(rs.getInt(5));
				bloggerone.setName(rs.getString(6));
				blog.setBlogger(bloggerone);
				bloglist.add(blog);
			}
		} catch (SQLException e) {	
			throw new BlogException("Error ");
		}
		finally {
			try {
				pst.close();
				//con.close();
			} catch (SQLException e) {			
				throw new BlogException("CONNECTION NOT CLOSED");
			}
			
		}

		return bloglist;
	}	
	/** 
	 * This method is used to search the blogger . 
	 * @param name this parameter is used to find the blogs by given bloggername.
	 * */
	public List<Blog> findByBloggerName(String name) 
	{
		Connection con=ConnectionDBUtil.getConnection();
		String query_show="select b.title, b.content, b.type, b.time, br.id, br.name , br.email, br.mobileNumber from blog b INNER JOIN  blogger br  on b.Id=br.Id WHERE br.name=?";
		PreparedStatement pstmt=null;
		List<Blog> bloglist=new ArrayList<Blog>();
		try {
			pstmt=con.prepareStatement(query_show);
			pstmt.setString(1, name);
			rs=pstmt.executeQuery();

			while(rs.next())
			{				
				Blog blog= new Blog();			
				Blogger bloggerone= new Blogger();
				blog.setTitle(rs.getString(1));
				blog.setContent(new StringBuffer(rs.getString(2)));
				blog.setType(rs.getString(3));
				blog.setTime(rs.getTimestamp(4));
				bloggerone.setId(rs.getInt(5));
				bloggerone.setName(rs.getString(6));
				blog.setBlogger(bloggerone);
				bloglist.add(blog);
			}
		} catch (SQLException e) {
			throw new BlogException("Error ");
		}
		finally {
			try {
				pstmt.close();
				//con.close();
			} catch (SQLException e) {			
				throw new BlogException("CONNECTION NOT CLOSED");
			}
		}
		return bloglist;
	}
}






