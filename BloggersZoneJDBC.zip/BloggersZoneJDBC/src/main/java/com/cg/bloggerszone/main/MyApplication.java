package com.cg.bloggerszone.main;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.math.BigInteger;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;

import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.dto.Blogger;
import com.cg.bloggerszone.exceptions.BlogException;
import com.cg.bloggerszone.service.BlogServiceImpl;
import com.cg.bloggerszone.service.IBlogService;


public class MyApplication {
	static IBlogService service;	
	/** 
	    * This is the main method which makes use of all the functionalities in the project. 
	    * @param args Unused. 
	    * @return Nothing. 
	 * 
	    */
	  
	public static void main(String args[]) throws IOException, SQLException {
		Blog blog;
		Blogger blogger ;
		service= new BlogServiceImpl();
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
	
		Scanner scr = new Scanner(System.in);
		StringBuffer content = null;

		int ch;
		do {
			print();
			System.out.println("Enter your choice");
			ch=scr.nextInt();
			switch(ch) {
			case 1:
				System.out.println("Enter Blogger Id");
				int id= scr.nextInt();
				System.out.println("Enter Blogger Name");
				String name= br.readLine();
				System.out.println("Enter Email ");
				String email=scr.next();
				System.out.println("Mobile Number");
				BigInteger mobileNumber=scr.nextBigInteger();
				System.out.println("Enter Blog Title");
				String title= br.readLine();
				System.out.println("Enter Blog Type");
				String type= br.readLine();
				System.out.println("Enter Blog Content");
				content= new StringBuffer(" ");
				String write;
				while (!((write =
						scr.next()).endsWith(".")))
				{
					content.append(write);
					content.append(" ");
				}
				blogger = new Blogger();
				blogger.setId(id);
				blogger.setName(name);
				blogger.setEmail(email);
				blogger.setMobileNumber(mobileNumber);
				blog = new Blog(title,content, type, new Timestamp(System.currentTimeMillis()), blogger);
				
				service.addBlog(blog);
				System.out.println(content);
				System.out.println("Blog is added successfully");
				
				break;
			case 2:
				System.out.println("Enter The Blog Title");
				String blogtitle=br.readLine();
				try {
					List<Blog> blogs=service.searchByTitle(blogtitle);
					for(Blog b: blogs) {
						System.out.println("**********************************");
						System.out.println("Title:"+b.getTitle());	
						System.out.println("Blog Type:"+b.getType());	
						System.out.println("\n"+b.getContent());	
						System.out.println("Time:"+b.getTime());	
						System.out.println("Blog Id:"+b.getBlogger().getId());
						System.out.println("Blog By:"+b.getBlogger().getName());
					}
				}catch(BlogException e) {
					System.out.println(e.getMessage());
				}

				break;		
			case 3:
				System.out.println("Enter The Blogger Name");
				String bloggername=br.readLine();
				try {

					List<Blog> blogSearch=service.searchByBloggerName(bloggername);	
					for(Blog bl: blogSearch) {
						System.out.println("**********************************");
						System.out.println("Title:"+bl.getTitle());	
						System.out.println("Blog Type:"+bl.getType());	
						System.out.println("\n"+bl.getContent());	
						System.out.println("Time:"+bl.getTime());	
						System.out.println("Blog By:"+bl.getBlogger().getName());
						System.out.println("**********************************");}
				}
				catch(BlogException e) {
					System.out.println(e.getMessage());
				}
				break;		
			case 4:	
				System.out.println("Exit");
				System.exit(0);

				break;
			default:
				System.out.println("Invalid Choice");break;
			}
		}while(ch<5);
	}
	public static void print() {
		System.out.println("********************************************");
		System.out.println("1.Add Blog");
		System.out.println("2.Search Blog by Title");
		System.out.println("3.Search Blog by Blogger Name");
		System.out.println("4.Exit");
		System.out.println("********************************************");
	}
}
