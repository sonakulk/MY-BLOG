package com.cg.bloggerszone.exceptions;

public class BlogException extends RuntimeException {

	public BlogException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public BlogException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
