package com.cg.bloggerszone.dto;

import java.sql.Timestamp;

public class Blog {
	
	private String title;
	private StringBuffer content;
	private String type;
	private   Timestamp time;
	private Blogger blogger;	
	public Blog()	{}
	public Blog(String title, StringBuffer content, String type, Timestamp time, Blogger blogger) {
		super();
		this.title = title;
		this.content = content;
		this.type = type;
		this.time = time;
		this.blogger = blogger;
	}
	public Blogger getBlogger() {
		return blogger;
	}

	public void setBlogger(Blogger blogger) {
		this.blogger = blogger;
	}
	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public StringBuffer getContent() {
		return content;
	}

	public void setContent(StringBuffer content) {
		this.content = content;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Timestamp getTime() {
		return time;
	}
	public void setTime(Timestamp time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "Blog [title=" + title + ", content=" + content + ", type=" + type + ", time=" + time + ", blogger="
				+ blogger + "]";
	}	
}
