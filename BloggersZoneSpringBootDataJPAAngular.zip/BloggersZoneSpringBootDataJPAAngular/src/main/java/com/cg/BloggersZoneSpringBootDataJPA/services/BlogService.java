package com.cg.BloggersZoneSpringBootDataJPA.services;

import java.sql.SQLException;
import java.util.List;

import com.cg.BloggersZoneSpringBootDataJPA.dto.Blog;
/*This is Service interface which contains  abstract methods for business logic.
 * 
 * @author	Sonal Kulkarni
 * Modified on 19-05-2019
 * 
 * */
public interface BlogService {

	public Blog addBlog(Blog blog) throws SQLException;
	public Blog addExistBlog(Blog blog);

	public List<Blog> searchByTitle(String title);

	public List<Blog> searchByBloggerName(String name);	
}
