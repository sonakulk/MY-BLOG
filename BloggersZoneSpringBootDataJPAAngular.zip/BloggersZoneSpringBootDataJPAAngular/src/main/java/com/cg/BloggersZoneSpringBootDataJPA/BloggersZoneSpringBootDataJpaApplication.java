package com.cg.BloggersZoneSpringBootDataJPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.cg.BloggersZoneSpringBootDataJPA")
public class BloggersZoneSpringBootDataJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BloggersZoneSpringBootDataJpaApplication.class, args);
		System.out.println("welcome to spring boot");
	}

}
