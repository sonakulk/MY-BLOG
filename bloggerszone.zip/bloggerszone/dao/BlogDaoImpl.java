package com.cg.bloggerszone.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.exceptions.BlogException;
import com.cg.bloggerszone.util.DBUtil;

public class BlogDaoImpl implements IBlogDao{

	public BlogDaoImpl() {}
	public Blog saveBlog(Blog blog) {
		DBUtil.blogs.add(blog);
		return blog ;	}

	public List<Blog> findByTitle(String title) {
		List<Blog> bloglist = new ArrayList<Blog>();
		for(Blog blog:DBUtil.blogs) {
			if(blog.getTitle().equals(title))
				bloglist.add(blog);	}
		if(bloglist.isEmpty()) 
			throw new BlogException("Blogs with this title not found");
		return  bloglist;		
	}
	public List<Blog> findByBloggerName(String name) 
	{
		List<Blog> mybloglist = new ArrayList<Blog>();		
		for(Blog blog:DBUtil.blogs) {
			if(blog.getBlogger().getName().equals(name)) 
				mybloglist.add(blog);				
		}
		if(mybloglist.isEmpty()) 
			throw new BlogException("Blogs with this blogger name not found");	
		return mybloglist;
	}

}
