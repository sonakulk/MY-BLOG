package com.cg.bloggerszone.service;

import java.util.List;

import com.cg.bloggerszone.dao.BlogDaoImpl;
import com.cg.bloggerszone.dao.IBlogDao;
import com.cg.bloggerszone.dto.Blog;

public class BlogServiceImpl implements IBlogService {
	
	IBlogDao dao;
	Blog blog;
	public BlogServiceImpl() {	
		dao=new BlogDaoImpl();
	}

	public Blog addBlog(Blog blog) {		
		return dao.saveBlog(blog);
	}

	public List<Blog> searchByTitle(String title) {	
		return dao.findByTitle(title);
	}
	
	public List<Blog> searchByBloggerName(String name) {	
		return dao.findByBloggerName(name);
	}

	

	

}
