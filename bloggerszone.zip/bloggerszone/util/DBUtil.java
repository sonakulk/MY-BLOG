package com.cg.bloggerszone.util;

import java.math.BigInteger;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import java.util.List;
import java.util.Map;

import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.dto.Blogger;

public class DBUtil {
	
	 static Timestamp timestamp = new Timestamp(System.currentTimeMillis());
	 static Blogger blogger = null;
	static StringBuffer sb;
	public  static List<Blog> blogs= new ArrayList<Blog>();

	static {
		Blogger bloggerone= new Blogger(1,"Aishwarya Patil","aishwaryapatil517@gmail.com",new BigInteger("7066825174"));
		Blogger bloggertwo= new Blogger(2,"Yshashree Joshi","yashuj95@gmail.com",new BigInteger("9545265877"));
		Blogger bloggerthree= new Blogger(3,"Tanaya Jadhav","tanayajadhav234@gmail.com",new BigInteger("9088256637"));
		Blogger bloggerfour= new Blogger(4,"Rutuja Chaodhari","rutujachaodhari4@gmail.com",new BigInteger("8890564578"));
		Blogger bloggerfive= new Blogger(5,"Nikita Deshmukh","deshmukhnikita456@yahoo.in",new BigInteger("9088256637"));
			
		Blog blogone = new Blog("Java",  new StringBuffer("Java is a programming language created by James Gosling from Sun Microsystems (Sun) in 1991."), "Study", timestamp,bloggerone);
		Blog blogtwo = new Blog("Morning",  new StringBuffer("When you arise in the morning, think of what a precious privilege it is to be alive - to breathe, to think, to enjoy, to love."), "Greetings", timestamp, bloggertwo);
		Blog blogthree = new Blog("JavaScript",  new StringBuffer("JavaScript is a lightweight, interpreted programming language. It is designed for creating network-centric applications. It is complimentary to and integrated with Java. JavaScript is very easy to implement because it is integrated with HTML. It is open and cross-platform."), "MorningQuote", timestamp, bloggerthree);
		Blog blogfour = new Blog("Thought of the day",  new StringBuffer("I can't change the direction of the wind, but I can adjust my sails to always reach my destination."), "InspirationalQuote", timestamp, bloggerfour);
		Blog blogfive = new Blog("JustThought",  new StringBuffer("Positivity, confidence, and persistence are key in life, so never give up on yourself."), "MotivationalQuote", timestamp, bloggerfive);
		
		blogs.add(blogone);
		blogs.add(blogtwo);
		blogs.add(blogthree);	
		blogs.add(blogfour);
		blogs.add(blogfive);
	}	
}
