package com.cg.bloggerszone.controller;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.cg.bloggerszone.dto.Blog;
import com.cg.bloggerszone.exceptions.BlogException;
import com.cg.bloggerszone.service.BlogService;
/*This is MyController class this work as controller for whole application 
 * Modified on 21-05-2019
 * @author	Sonal Kulkarni
 * 
 * 
 * */
@RestController
@RequestMapping("/bloggerszone")
public class MyController {
	/* Autowired the IBlogService object. */
	@Autowired
	BlogService service;
	
	/* This method map to http://localhost:9090/BloggersZoneSpringMvc/addblog
	 * @param @ModelAttribute blog
	 * @return blog
	 * 
	 * */
	@RequestMapping(value="/addblog",method=RequestMethod.POST)
	public ResponseEntity<Blog> addProduct(@ModelAttribute("blog") Blog blog) throws SQLException {
		System.out.println(blog);
		blog.setTime(new Timestamp(System.currentTimeMillis()));
		Blog blogg=service.addBlog(blog);
		if(blogg==null) {
			return new ResponseEntity("blog Not Found",HttpStatus.NOT_FOUND);
		}	
		return new ResponseEntity(blogg,HttpStatus.OK);
	}
	
	/* This method map to http://localhost:9090/BloggersZoneSpringMvc/searchbytitle
	 * @param @ModelAttribute blog
	 * @return ModelAndView
	 * 
	 * */
	/*@RequestMapping(value="/searchbytitle",method=RequestMethod.POST)
	public List<Blog> searchProduct(@RequestParam("title") String title)
	{
		List<Blog> mylist =service.searchByTitle(title);
		return  mylist;

	}
	 This method map to http://localhost:9090/BloggersZoneSpringMvc/searchbybloggername
	 * @param @ModelAttribute blog
	 * @return ModelAndView
	 * 
	 * 
	@RequestMapping(value="/searchbybloggername",method=RequestMethod.POST)
	public List<Blog>  searchByBlogger(@RequestParam("name")String name) {

		List<Blog> b=service.searchByBloggerName(name);
		return b;	

	}
	http://localhost:9090/BloggersZoneSpringMvc/addblogbyexistingblogger
	 * @param @ModelAttribute blog
	 * @return ModelAndView
	 * 
	 * 
	@GetMapping("addblogbyexistingblogger")
	public ModelAndView getBlogExist(@ModelAttribute ("blog") Blog blog) {
		return new ModelAndView("addblogbyexistingblogger");

	}
	http://localhost:9090/BloggersZoneSpringMvc/addblogbyexistingblogger
	 * @param @ModelAttribute blog
	 * @return ModelAndView
	 * 
	 * 
	@PostMapping("addblogbyexistingblogger")
	public ModelAndView addBlogExist(@ModelAttribute("blog")Blog blog) throws SQLException {

		Blog b=service.addExistBlog(blog);
		return new ModelAndView("addblogbyexistingblogger","addblogexist",b);

	}

	This is @ExceptionHandler method
	 * Handles @BlogException
	 * 
	@ExceptionHandler({BlogException.class})
	public ResponseEntity handleBlogException(BlogException be) {
		return  new ResponseEntity(be.getMessage(),HttpStatus.NOT_FOUND);

	} 




*/






}
