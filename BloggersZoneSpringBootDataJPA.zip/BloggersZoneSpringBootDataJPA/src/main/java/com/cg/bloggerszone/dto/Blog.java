package com.cg.bloggerszone.dto;

import java.sql.Timestamp;
import java.util.Date;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;


/*The class Blog contains all the basic important details of the blog
 * such as title,content,type,time and Blogger
 * and the getters and setters of all.
 * 
 *Last Modified 20/05/2019  04.30 p.m.
 * @Author: Sonal Kulkarni
 * */
@Entity
public class Blog {
	@Id
	@Column(name="blog_title")
	private String title;				//this attribute is used to store title of the blog
	@Column(name="content",length=1000)
	private StringBuilder content;		//this attribute is used to store content of the blog
	@Column(name="type")
	private String type;				//this attribute is used to store type of the blog
	@Column(name="time")
	private   Timestamp time;			//this attribute is used to store time when the blog is added
	@ManyToOne(cascade= {CascadeType.PERSIST,CascadeType.ALL } )
	@JoinColumn(name="blogger_id" )
	
	
	private Blogger blogger;	//this attribute is used to store blogger details and represents many to one relationship
	public Blog()	{}
	public Blog(String title, StringBuilder content, String type,  Timestamp time, Blogger blogger) {
		super();
		this.title = title;
		this.content = content;
		this.type = type;
		this.time = time;
		this.blogger = blogger;
	}
	public Blogger getBlogger() {
		return blogger;
	}

	public void setBlogger(Blogger blogger) {
		this.blogger = blogger;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public StringBuilder getContent() {
		return content;
	}

	public void setContent(StringBuilder content) {
		this.content = content;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public  Timestamp getTime() {
		return time;
	}
	public void setTime( Timestamp time) {
		this.time = time;
	}
	@Override
	public String toString() {
		return "Blog [title=" + title + ", content=" + content + ", type=" + type + ", time=" + time + ", blogger="
				+ blogger + "]";
	}	
}
