package com.cg.bloggerszone.exceptions;

/*This is BlogException class extends RuntimeExceptions
 * Modified on 19-05-2019
 * @author	Sonal Kulkarni
 * 
 * */
public class BlogException extends RuntimeException {

	public BlogException() {
		super();
	}
	public BlogException(String message) {
		super(message);
	}


}
